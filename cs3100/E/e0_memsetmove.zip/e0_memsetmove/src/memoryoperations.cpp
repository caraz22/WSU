#include "MemoryOperations.h"
#include "Pet.h"

///////////////////////////////////////////////////////////////////////////////
Pet* MemoryOperations::memmove(
    Pet* destination_p, const Pet* source_p, size_t count)
{
    const Pet* sourceEnd_p = source_p + count;
    // const Pet* sourceEnd_p = &source_p[count]; 
    // Pet* current_p = destination_p;

    // while (source_p < sourceEnd_p)
    // {
    //     *current_p++ = *source_p++;
    //     // ++destination_p;
    //     // ++source_p;
    // }
    
    // if (destination_p > source_p)
    // {
    //     for (int32_t i = count; i >= 0; --i)
    //     {
    //         {
    //         destination_p[i] = source_p[i];
    //         }               
    //     }
 
    // } else 
    // {
    //     for (int32_t i = 0; i < count; ++i)       
    //     {
    //         destination_p[i] = source_p[i];
    //     } 
    // }

    if (destination_p > source_p)
    {  
        Pet* current_p = destination_p + count - 1;
        const Pet* sourceEnd_p = source_p + count - 1;
        while (sourceEnd_p >= source_p)
        {
            *current_p-- = *sourceEnd_p--;
        }
    } else
    {
        Pet* current_p = destination_p;
        const Pet* sourceEnd_p = source_p + count;
        while (source_p < sourceEnd_p)
        {
            *current_p++ = *source_p++;
        }
    }

    return destination_p;
}
